﻿using System;

namespace MailContainerApp.UI
{
    public class Class1
    {
    }
}
