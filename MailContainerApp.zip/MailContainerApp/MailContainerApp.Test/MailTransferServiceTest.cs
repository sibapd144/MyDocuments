﻿using MailContainerApp.Domain.Contract;
using MailContainerApp.Domain.Enum;
using MailContainerApp.Domain.Model;
using MailContainerApp.Service;
using Moq;
using System;
using Xunit;

namespace MailContainerApp.Test
{
    public class MailTransferServiceTest
    {
        private readonly MailTransferService _mts;
        private readonly Mock<IContainerDatastore> _ContainerDataStore = new Mock<IContainerDatastore>();      
        public MailTransferServiceTest()
        {
            _mts = new MailTransferService(_ContainerDataStore.Object);
        }

        [Fact]
        public void Check_IsRequestValid()
        {
            //Arrange
            MailContainer SourcemailContainer = new MailContainer()
            {
                   MailContainerNumber= "ContainerA1",
                   Status =Domain.Enum.MailContainerStatus.Operational,
                   AllowedMailType= AllowedMailType.LargeLetter,
                   Capacity= 100
            };
            MailContainer DestinationmailContainer = new MailContainer()
            {
                MailContainerNumber = "ContainerA1",
                Status = Domain.Enum.MailContainerStatus.Operational,
                AllowedMailType = AllowedMailType.LargeLetter,
                Capacity = 100
            };
            MakeMailTransferRequest request = new MakeMailTransferRequest()
            {
                SourceMailContainerNumber = "ContainerA1",
                DestinationMailContainerNumber = "ContainerB1",
                NumberOfMailItems = 1,
                TransferDate = DateTime.Now,
                MailType = Domain.Enum.MailType.LargeLetter
            };
            MailTransferContainerDetails ContainerDetails = new MailTransferContainerDetails()
            {
                SourceMailContainer= SourcemailContainer,
                DestinationMailContainer= DestinationmailContainer
            };
            MakeMailTransferResult result = new MakeMailTransferResult
            {
                Success=true
            };
            //Act
            result = _mts.IsRequestValid(ContainerDetails, request);

            //Assert           
            Assert.True(result.Success);
            
        }

        [Fact]
        public void Check_MakeMailTransfer_ShouldReturnResult()
        {
            //Arrange
            MailContainer SourcemailContainer = new MailContainer()
            {
                MailContainerNumber = "ContainerA1",
                Status = Domain.Enum.MailContainerStatus.Operational,
                AllowedMailType = AllowedMailType.LargeLetter,
                Capacity = 100
            };
            MailContainer DestinationmailContainer = new MailContainer()
            {
                MailContainerNumber = "ContainerA1",
                Status = Domain.Enum.MailContainerStatus.Operational,
                AllowedMailType = AllowedMailType.LargeLetter,
                Capacity = 100
            };
            MakeMailTransferRequest request = new MakeMailTransferRequest()
            {
                SourceMailContainerNumber = "ContainerA1",
                DestinationMailContainerNumber = "ContainerB1",
                NumberOfMailItems = 1,
                TransferDate = DateTime.Now,
                MailType = Domain.Enum.MailType.LargeLetter
            };
            MailTransferContainerDetails ContainerDetails = new MailTransferContainerDetails();
            _ContainerDataStore.Setup( a=>a.GetMailTransferDetails(request)).Returns(ContainerDetails);   
            MakeMailTransferResult result = new MakeMailTransferResult
            {
                Success = true
            };
            //Act
            ContainerDetails.SourceMailContainer.Capacity -= request.NumberOfMailItems;
            ContainerDetails.DestinationMailContainer.Capacity += request.NumberOfMailItems;
            //Assert
            _ContainerDataStore.Setup(a => a.UpdateMailContainer(ContainerDetails)).Verifiable();
        }

        [Fact]
        public void Check_RequestForTransfer_ShouldValidateRequest_AndUpdateInDatabase()
        {
            //Arrange
            MailContainer SourcemailContainer = new MailContainer()
            {
                MailContainerNumber = "ContainerA1",
                Status = Domain.Enum.MailContainerStatus.Operational,
                AllowedMailType = AllowedMailType.LargeLetter,
                Capacity = 100
            };
            MailContainer DestinationmailContainer = new MailContainer()
            {
                MailContainerNumber = "ContainerA1",
                Status = Domain.Enum.MailContainerStatus.Operational,
                AllowedMailType = AllowedMailType.LargeLetter,
                Capacity = 100
            };
            MakeMailTransferRequest request = new MakeMailTransferRequest()
            {
                SourceMailContainerNumber = "ContainerA1",
                DestinationMailContainerNumber = "ContainerB1",
                NumberOfMailItems = 1,
                TransferDate = DateTime.Now,
                MailType = Domain.Enum.MailType.LargeLetter
            };
            MailTransferContainerDetails ContainerDetails = new MailTransferContainerDetails()
            {
                SourceMailContainer = SourcemailContainer,
                DestinationMailContainer = DestinationmailContainer
            };
            MakeMailTransferResult result = new MakeMailTransferResult
            {
                Success = true
            };
            //Act
            ContainerDetails.SourceMailContainer.Capacity -= request.NumberOfMailItems;
            ContainerDetails.DestinationMailContainer.Capacity += request.NumberOfMailItems;
            //Assert
            _ContainerDataStore.Setup(a => a.UpdateMailContainer(ContainerDetails)).Verifiable();         
            
        }

      
    }
}
