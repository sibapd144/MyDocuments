﻿using MailContainerApp.Domain.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace MailContainerApp.Domain.Contract
{
    public interface IContainerDatastore
    {
        public MailContainer GetMailContainer(string mailContainerNumber);
        public void UpdateMailContainer(MailContainer mailContainer);
        public MailTransferContainerDetails GetMailTransferDetails(MakeMailTransferRequest Request);
        public void UpdateMailContainer(MailTransferContainerDetails MailTransferContainers);
    }
}
