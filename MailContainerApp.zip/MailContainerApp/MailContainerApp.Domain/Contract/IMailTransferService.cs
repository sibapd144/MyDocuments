﻿using MailContainerApp.Domain.Model;

namespace MailContainerApp.Domain.Contract
{
    public interface IMailTransferService
    {
        MakeMailTransferResult MakeMailTransfer(MakeMailTransferRequest request);
    }
}