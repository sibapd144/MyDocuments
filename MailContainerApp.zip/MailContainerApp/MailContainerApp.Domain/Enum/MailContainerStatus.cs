﻿namespace MailContainerApp.Domain.Enum
{
    public enum MailContainerStatus
    {
        Operational,
        OutOfService,
        NoTransfersIn
    }
}