﻿namespace MailContainerApp.Domain.Enum
{
    public enum MailType
    {
        StandardLetter,
        LargeLetter,
        SmallParcel
    }
}
