﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MailContainerApp.Domain.Model
{
    public  class MailTransferContainerDetails
    {
        public  MailContainer SourceMailContainer;
        public  MailContainer DestinationMailContainer;
        //  need to add data store 
    }
}
