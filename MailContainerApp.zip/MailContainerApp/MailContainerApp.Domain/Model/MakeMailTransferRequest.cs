﻿using MailContainerApp.Domain.Enum;
using System;

namespace MailContainerApp.Domain.Model
{
    public class MakeMailTransferRequest
    {
        public string SourceMailContainerNumber { get; set; }   
        public string DestinationMailContainerNumber { get; set; }
        public int NumberOfMailItems { get; set; }
        public DateTime TransferDate { get; set; }   
        public MailType MailType { get; set; }  
    }
}
