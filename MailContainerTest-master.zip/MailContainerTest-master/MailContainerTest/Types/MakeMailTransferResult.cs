﻿namespace MailContainerTest.Types
{
    public class MakeMailTransferResult
    {
        public bool Success { get; set; }   
    }
}
