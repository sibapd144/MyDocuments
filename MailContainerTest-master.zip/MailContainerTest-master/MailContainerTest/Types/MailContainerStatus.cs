﻿namespace MailContainerTest.Types
{
    public enum MailContainerStatus
    {
        Operational,
        OutOfService,
        NoTransfersIn
    }
}